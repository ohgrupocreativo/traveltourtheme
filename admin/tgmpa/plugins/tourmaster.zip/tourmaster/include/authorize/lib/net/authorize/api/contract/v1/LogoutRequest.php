<?php

namespace net\authorize\api\contract\v1;

/**
 * Class representing LogoutRequest
 */
class LogoutRequest extends ANetApiRequestType
{


}

